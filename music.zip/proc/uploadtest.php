<?php
print_r($_FILES);
?>