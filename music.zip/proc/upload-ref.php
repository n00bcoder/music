<?php

/*
In order for this to work, upload_max_filesize and post_max_size in php.ini need to be set correctly
*/

$target_dir = "../music/";
$target_dir = $target_dir . basename( $_FILES["uploadFile"]["name"]);
$uploadOk=1;

if (move_uploaded_file($_FILES["uploadFile"]["tmp_name"], $target_dir)) {
    echo "The file ". basename( $_FILES["uploadFile"]["name"]). " has been uploaded.";
} else {
    echo "Sorry, there was an error uploading your file.";
}

/*
Get redirection happening, along with notifying user that upload was success or not
*/

?> 